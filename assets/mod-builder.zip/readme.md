# TC's Mod builder
Simple mod build that has everything build in for you to build a mod


```bash
npm run build # builds mod and outputs in dist folder where you can use to install the mod
npm run build:all # builds all mods from mods folder
```