# TC's Mod builder
Simple mod builder that has everything build in for you to build a mod

# Examples
Examples can be found in mods folder


```bash
npm run build # builds mod and outputs in dist folder where you can use to install the mod
npm run build:all # builds all mods from mods folder
npm run dev # Opens a dev server on which the Mod loader can connect to receive mod as soon as they are compiled 
```